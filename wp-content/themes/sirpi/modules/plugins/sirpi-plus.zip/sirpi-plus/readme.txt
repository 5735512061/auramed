======= Sirpi Plus =====

Sirpi Plus plugin adds additonal features for Sirpi theme.


== Changelog ==

= 1.0.0 =

    * First release!