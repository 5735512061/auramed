===== Sirpi Pro =====

Sirpi Pro plugin adds advanced features for Sirpi theme.


== Changelog ==

= 1.0.0 =

    * First release!