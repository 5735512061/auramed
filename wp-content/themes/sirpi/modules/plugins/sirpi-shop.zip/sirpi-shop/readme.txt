===== Sirpi Shop =====

Sirpi Shop plugin adds shop features for Sirpi theme.


== Changelog ==

= 1.0.0 =

    * First release!